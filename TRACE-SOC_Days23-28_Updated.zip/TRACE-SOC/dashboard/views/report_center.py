"""Day 27: structured analyst handover export view."""
import json
import streamlit as st
from reports.analyst_exports import build_investigation_package,investigation_timeline_csv
from dashboard.data_access import get_stories

def render_report_center():
    st.markdown("## Analyst Report Center")
    st.caption("Export investigation evidence, timeline, alert links and integrity references for handover.")
    stories=get_stories(limit=500)
    if not stories:
        st.info("No investigation stories are available.")
        return
    selected=st.selectbox("Select investigation",[s["id"] for s in stories],
        format_func=lambda x:f"#{x} — {next(s['title'] for s in stories if s['id']==x)}")
    if st.button("Prepare handover exports",type="primary"):
        try:
            package=build_investigation_package(selected)
            csv_text=investigation_timeline_csv(selected)
            st.session_state["handover_json"]=json.dumps(package,indent=2,default=str)
            st.session_state["handover_csv"]=csv_text
            st.success("Handover exports prepared.")
        except Exception as exc: st.error(f"Could not prepare report: {exc}")
    if "handover_json" in st.session_state:
        st.download_button("Download investigation handover JSON",st.session_state["handover_json"],
            file_name=f"TRACE-SOC-story-{selected}-handover.json",mime="application/json")
        st.download_button("Download event timeline CSV",st.session_state["handover_csv"],
            file_name=f"TRACE-SOC-story-{selected}-timeline.csv",mime="text/csv")
        st.caption("The export is a snapshot of local records at preparation time. Review sensitive fields before sharing.")
