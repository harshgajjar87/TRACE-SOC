"""Day 24: forensic timeline analysis view."""
import csv,io
import streamlit as st
from investigation.forensic_timeline import analyze_forensic_timeline

def render_forensic_timeline():
    st.markdown("## Forensic Timeline Analysis")
    st.caption("Inspect event chronology, elapsed time gaps and stored correlation relationships.")
    story_id=st.number_input("Investigation story ID",min_value=1,step=1,key="forensic_story_id")
    threshold=st.slider("Highlight gaps of at least (minutes)",1,240,15)
    if st.button("Analyze timeline",type="primary"):
        try: st.session_state["forensic_timeline_result"]=analyze_forensic_timeline(int(story_id),threshold)
        except Exception as exc: st.error(str(exc))
    result=st.session_state.get("forensic_timeline_result")
    if not result: return
    stats=result["statistics"]
    a,b,c=st.columns(3)
    a.metric("Timeline events",stats["event_count"])
    b.metric("Large gaps",stats["large_gap_count"])
    c.metric("Gap threshold",f'{stats["threshold_minutes"]} min')
    st.markdown(f"### {result['story'].get('title','Investigation')}")
    st.dataframe(result["events"],use_container_width=True,hide_index=True)
    with st.expander("Correlation relationships"):
        st.dataframe(result["relationships"],use_container_width=True,hide_index=True)
    output=io.StringIO()
    fields=["timestamp_utc","normalized_event_id","event_id","event_type","hostname","username",
            "source_ip","destination_ip","image","command_line","raw_event_id",
            "gap_from_previous_minutes","timeline_marker"]
    writer=csv.DictWriter(output,fieldnames=fields,extrasaction="ignore")
    writer.writeheader();writer.writerows(result["events"])
    st.download_button("Download forensic timeline CSV",output.getvalue(),
        file_name=f"TRACE-SOC-story-{story_id}-timeline.csv",mime="text/csv")
    st.caption("Large gaps are time differences between adjacent stored events, not evidence that activity stopped.")
