"""Day 28: system health and database readiness dashboard."""
import streamlit as st
from operations.health import get_system_health,create_performance_indexes

def render_system_health():
    st.markdown("## System Health & Performance")
    st.caption("Local SQLite health, referential integrity and operational data availability.")
    if st.button("Create recommended performance indexes"):
        try:
            count=create_performance_indexes()
            st.success(f"Checked/created {count} indexes. Existing indexes were left intact.")
        except Exception as exc: st.error(f"Index maintenance failed: {exc}")
    health=get_system_health()
    a,b,c=st.columns(3)
    a.metric("SQLite quick check",health["sqlite_quick_check"])
    b.metric("Foreign-key issues",len(health["foreign_key_issues"]))
    c.metric("Database size",f'{health["database_size_bytes"]/1024/1024:.1f} MB')
    st.markdown("### Database details")
    st.json({k:v for k,v in health.items() if k not in {"table_counts","foreign_key_issues"}})
    st.markdown("### Stored record counts")
    st.dataframe([{"table":k,"records":v} for k,v in health["table_counts"].items()],use_container_width=True,hide_index=True)
    if health["foreign_key_issues"]: st.error("SQLite reported foreign-key violations.")
    if health["sqlite_quick_check"]!="ok": st.error("SQLite quick_check did not return ok.")
    if health["missing_expected_tables"]: st.warning("Some optional component tables have not been initialized: "+", ".join(health["missing_expected_tables"]))
    st.caption("This page performs local read-only health checks except when you explicitly choose to create indexes. It does not certify the host OS or endpoint security posture.")
