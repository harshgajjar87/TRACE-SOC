"""Day 25: detection quality dashboard."""
import streamlit as st
from detection.quality import get_detection_quality_summary

def render_detection_quality():
    st.markdown("## Detection Rule Quality")
    st.caption("Compare configured custom rules with alert outcomes recorded in TRACE-SOC.")
    data=get_detection_quality_summary()
    a,b,c,d=st.columns(4)
    a.metric("Configured rules",data["configured_rules"])
    b.metric("Rules observed",data["rules_observed"])
    c.metric("Stored alerts",data["total_alerts"])
    d.metric("False-positive rate",f'{data["false_positive_rate_pct"]}%')
    st.dataframe(data["rules"],use_container_width=True,hide_index=True)
    st.info("NOT_OBSERVED means no alert for that rule is currently stored. It does not prove the rule is broken or that the technique is absent. False-positive rate is based on analyst status labels and can change as alerts are reclassified.")
