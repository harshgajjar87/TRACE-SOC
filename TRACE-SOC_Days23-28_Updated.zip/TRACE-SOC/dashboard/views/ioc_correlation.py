"""Day 26: local IOC-to-telemetry correlation view."""
import streamlit as st
from threat_intel.correlation import run_ioc_correlation,get_ioc_sightings,get_ioc_sighting_summary

def render_ioc_correlation():
    st.markdown("## IOC Correlation")
    st.caption("Match normalized endpoint telemetry against the active local IOC inventory.")
    summary=get_ioc_sighting_summary()
    a,b,c=st.columns(3)
    a.metric("Persisted sightings",summary["total_sightings"])
    b.metric("Unique indicators",summary["unique_iocs"])
    c.metric("Events matched",summary["unique_events"])
    limit=st.slider("Maximum recent events to scan",100,5000,1000,100)
    if st.button("Run IOC correlation",type="primary"):
        try:
            result=run_ioc_correlation(limit)
            st.success(f"Scanned {result['events_scanned']} events; inserted {result['sightings_inserted']} new sightings.")
            st.rerun()
        except Exception as exc: st.error(f"IOC correlation failed: {exc}")
    st.markdown("### IOC sightings")
    rows=get_ioc_sightings(1000)
    if rows: st.dataframe(rows,use_container_width=True,hide_index=True)
    else: st.info("No IOC sightings recorded. Import indicators and run correlation to populate this view.")
    st.caption("A match means local indicator data matched available event fields. It is not a verdict that the endpoint is compromised.")
