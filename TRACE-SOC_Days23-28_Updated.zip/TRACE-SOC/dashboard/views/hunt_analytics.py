"""Day 23: pivot-based threat hunting analytics view."""
import streamlit as st
from hunting.analytics import get_hunt_activity_summary,get_related_events,get_process_lineage

def render_hunt_analytics():
    st.markdown("## Threat Hunt Analytics")
    st.caption("Pivot from a selected normalized event to related host, user, IP and process activity.")
    summary=get_hunt_activity_summary()
    a,b,c=st.columns(3)
    a.metric("Normalized events",summary["total_events"])
    b.metric("Hosts observed",len(summary["hosts"]))
    c.metric("Distinct process images",len(summary["processes"]))
    left,right=st.columns(2)
    with left:
        st.markdown("### Most active hosts")
        st.dataframe(summary["hosts"],use_container_width=True,hide_index=True)
        st.markdown("### Most active accounts")
        st.dataframe(summary["users"],use_container_width=True,hide_index=True)
    with right:
        st.markdown("### Common event IDs")
        st.dataframe(summary["event_ids"],use_container_width=True,hide_index=True)
        st.markdown("### Common process images")
        st.dataframe(summary["processes"],use_container_width=True,hide_index=True)
    st.divider()
    event_id=st.number_input("Normalized event ID to pivot from",min_value=1,step=1,key="pivot_event_id")
    window=st.slider("Related-event time window (minutes)",1,240,15,key="pivot_window")
    if st.button("Run event pivot",type="primary"):
        try:
            st.session_state["pivot_related"]=get_related_events(int(event_id),window)
            st.session_state["pivot_lineage"]=get_process_lineage(int(event_id))
        except Exception as exc: st.error(str(exc))
    if "pivot_related" in st.session_state:
        st.markdown("### Related events")
        st.dataframe(st.session_state["pivot_related"],use_container_width=True,hide_index=True)
        st.markdown("### Process lineage matches")
        st.dataframe(st.session_state.get("pivot_lineage",[]),use_container_width=True,hide_index=True)
        st.caption("Pivot results show shared attributes and time proximity; they are investigative leads, not proof of causation.")
