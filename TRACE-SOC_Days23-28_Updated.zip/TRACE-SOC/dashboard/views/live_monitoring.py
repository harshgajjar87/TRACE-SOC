
"""TRACE-SOC live endpoint monitoring dashboard page."""

import json

import pandas as pd
import streamlit as st

from monitoring.engine import (
    create_monitoring_schema,
    get_monitoring_runs,
    get_monitoring_status,
    get_monitoring_summary,
)


def render_live_monitoring():
    create_monitoring_schema()

    st.title("Live Endpoint Monitoring")
    st.caption(
        "Monitor Windows endpoint collection health and polling history."
    )

    status = get_monitoring_status()
    summary = get_monitoring_summary()
    runs = get_monitoring_runs(limit=50)

    service_status = status.get("service_status", "UNKNOWN")

    if service_status == "RUNNING":
        st.success("Monitoring service is marked as RUNNING.")
    elif service_status == "ERROR":
        st.error("Monitoring service has reported an error.")
    else:
        st.warning(
            "Monitoring service is currently STOPPED. "
            "Start it from the monitoring terminal."
        )

    st.subheader("Service status")

    col1, col2, col3 = st.columns(3)

    col1.metric("Service status", service_status)
    col2.metric(
        "Polling interval",
        f"{status.get('polling_interval_seconds', 0)} sec",
    )
    col3.metric(
        "Last successful run",
        status.get("last_success_at_utc") or "Not available",
    )

    if status.get("last_error"):
        st.error(f"Latest collection error: {status['last_error']}")

    st.divider()
    st.subheader("Collection statistics")

    col1, col2, col3 = st.columns(3)

    col1.metric("Total polling cycles", summary["total_runs"])
    col2.metric("Successful cycles", summary["successful_runs"])
    col3.metric("Failed cycles", summary["failed_runs"])

    col4, col5, col6 = st.columns(3)

    col4.metric("Events received", summary["total_received"])
    col5.metric("Events inserted", summary["total_inserted"])
    col6.metric("Duplicates skipped", summary["total_duplicates"])

    st.divider()
    st.subheader("Recent collection history")

    if not runs:
        st.info(
            "No monitoring cycles recorded yet. "
            "Start the monitoring service to see activity here."
        )
    else:
        dataframe = pd.DataFrame(runs)

        display_columns = [
            "id",
            "started_at_utc",
            "completed_at_utc",
            "status",
            "total_received",
            "total_inserted",
            "total_duplicates",
        ]

        st.dataframe(
            dataframe[display_columns],
            use_container_width=True,
            hide_index=True,
        )

        st.subheader("Collection cycle details")

        selected_id = st.selectbox(
            "Select a collection cycle",
            options=[run["id"] for run in runs],
        )

        selected_run = next(
            run for run in runs if run["id"] == selected_id
        )

        st.write("**Status:**", selected_run["status"])
        st.write("**Started:**", selected_run["started_at_utc"])
        st.write("**Completed:**", selected_run["completed_at_utc"])

        try:
            channel_data = json.loads(
                selected_run["channels_json"] or "{}"
            )
            st.json(channel_data)
        except (TypeError, json.JSONDecodeError):
            st.warning("Could not read channel details.")

        if selected_run["error_message"]:
            st.error(selected_run["error_message"])

    if st.button("Refresh monitoring data"):
        st.rerun()
