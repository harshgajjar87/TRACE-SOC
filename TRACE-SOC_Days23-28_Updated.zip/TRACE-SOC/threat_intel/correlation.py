"""Day 26: persist IOC sightings linked to normalized endpoint events."""
from datetime import datetime, timezone
import json
from database.db import get_connection
from threat_intel.engine import enrich_event, create_threat_intel_schema

def create_ioc_sighting_schema():
    create_threat_intel_schema()
    conn=get_connection()
    try:
        with conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS ioc_sightings(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ioc_id INTEGER NOT NULL,
                normalized_event_id INTEGER NOT NULL,
                matched_field TEXT,
                first_seen_utc TEXT NOT NULL,
                match_details_json TEXT,
                UNIQUE(ioc_id,normalized_event_id),
                FOREIGN KEY(ioc_id) REFERENCES ioc_indicators(id),
                FOREIGN KEY(normalized_event_id) REFERENCES normalized_events(id)
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ioc_sightings_event ON ioc_sightings(normalized_event_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ioc_sightings_ioc ON ioc_sightings(ioc_id)")
    finally: conn.close()

def run_ioc_correlation(limit=1000):
    """Match most recent normalized events against active local IOCs and persist sightings."""
    create_ioc_sighting_schema()
    limit=max(1,min(int(limit),5000))
    conn=get_connection()
    try:
        events=[dict(r) for r in conn.execute("""SELECT * FROM normalized_events
            ORDER BY timestamp_utc DESC,id DESC LIMIT ?""",(limit,)).fetchall()]
    finally: conn.close()
    matched=0
    for event in events:
        for ioc in enrich_event(event):
            conn=get_connection()
            try:
                with conn:
                    conn.execute("""INSERT OR IGNORE INTO ioc_sightings(
                        ioc_id,normalized_event_id,matched_field,first_seen_utc,match_details_json
                    ) VALUES(?,?,?,?,?)""",(
                        ioc["id"],event["id"],ioc.get("matched_field"),
                        event.get("timestamp_utc") or datetime.now(timezone.utc).isoformat(),
                        json.dumps({"ioc_type":ioc.get("ioc_type"),"indicator":ioc.get("indicator"),
                                    "source_name":ioc.get("source_name"),"confidence":ioc.get("confidence"),
                                    "severity":ioc.get("severity")},sort_keys=True)
                    ))
                    matched+=conn.total_changes
            finally: conn.close()
    return {"events_scanned":len(events),"sightings_inserted":matched}

def get_ioc_sightings(limit=500):
    create_ioc_sighting_schema()
    limit=max(1,min(int(limit),5000))
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT s.id,s.first_seen_utc,s.matched_field,
            i.ioc_type,i.indicator,i.source_name,i.confidence,i.severity,
            ne.id AS normalized_event_id,ne.event_id,ne.hostname,ne.username,
            ne.source_ip,ne.destination_ip,ne.image,ne.command_line
            FROM ioc_sightings s JOIN ioc_indicators i ON i.id=s.ioc_id
            JOIN normalized_events ne ON ne.id=s.normalized_event_id
            ORDER BY s.id DESC LIMIT ?""",(limit,)).fetchall()
        return [dict(r) for r in rows]
    finally: conn.close()

def get_ioc_sighting_summary():
    create_ioc_sighting_schema()
    conn=get_connection()
    try:
        total=conn.execute("SELECT COUNT(*) FROM ioc_sightings").fetchone()[0]
        unique_iocs=conn.execute("SELECT COUNT(DISTINCT ioc_id) FROM ioc_sightings").fetchone()[0]
        unique_events=conn.execute("SELECT COUNT(DISTINCT normalized_event_id) FROM ioc_sightings").fetchone()[0]
        by_severity=[dict(r) for r in conn.execute("""SELECT i.severity,COUNT(*) AS count
            FROM ioc_sightings s JOIN ioc_indicators i ON i.id=s.ioc_id
            GROUP BY i.severity ORDER BY count DESC""").fetchall()]
        return {"total_sightings":total,"unique_iocs":unique_iocs,"unique_events":unique_events,"by_severity":by_severity}
    finally: conn.close()
