"""Day 27: structured investigation export helpers."""
import csv
import io
from datetime import datetime, timezone
from investigation.investigation_queries import get_investigation
from investigation.evidence import get_story_evidence, verify_raw_event_integrity
from investigation.chain_of_custody import get_custody_history

def build_investigation_package(story_id):
    """Build a JSON-serializable analyst handover package from stored records."""
    result=get_investigation(int(story_id))
    if not result or not result.get("story"):
        raise ValueError(f"Investigation story {story_id} was not found.")
    evidence=[]
    for item in get_story_evidence(int(story_id)):
        check=verify_raw_event_integrity(item["raw_event_id"])
        evidence.append({**item,"integrity":check,
                         "custody_history":get_custody_history(item["raw_event_id"])})
    return {
        "product":"TRACE-SOC","export_type":"investigation_handover",
        "generated_at_utc":datetime.now(timezone.utc).isoformat(),
        "limitations":[
            "Correlation scores describe analytical relationships, not attack probability.",
            "A SHA-256 match verifies stored bytes against the recorded baseline only.",
            "The package contains records currently stored in the local TRACE-SOC database."
        ],
        "story":result.get("story"),
        "timeline":result.get("timeline",[]),
        "relationships":result.get("relationships",[]),
        "alerts":result.get("alerts",[]),
        "evidence":evidence,
    }

def investigation_timeline_csv(story_id):
    package=build_investigation_package(story_id)
    output=io.StringIO()
    fields=["timestamp_utc","normalized_event_id","event_id","event_type","hostname",
            "username","source_ip","destination_ip","image","command_line","raw_event_id",
            "alert_id","alert_severity"]
    writer=csv.DictWriter(output,fieldnames=fields,extrasaction="ignore")
    writer.writeheader()
    writer.writerows(package["timeline"])
    return output.getvalue()
