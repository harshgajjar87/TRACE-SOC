"""Day 25: detection-rule operational quality and alert outcome metrics."""
from detection.rules import DETECTION_RULES
from database.db import get_connection

def get_detection_quality():
    """Combine configured rule inventory with observed alert counts and outcomes."""
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT rule_id,COUNT(*) AS alert_count,
            SUM(CASE WHEN status='FALSE_POSITIVE' THEN 1 ELSE 0 END) AS false_positives,
            SUM(CASE WHEN status IN ('NEW','INVESTIGATING') THEN 1 ELSE 0 END) AS open_alerts,
            MAX(created_at_utc) AS last_alert_at
            FROM alerts GROUP BY rule_id""").fetchall()
        observed={r["rule_id"]:dict(r) for r in rows}
        output=[]
        for rule in DETECTION_RULES:
            rid=rule.get("rule_id")
            stats=observed.get(rid,{})
            count=int(stats.get("alert_count") or 0)
            fp=int(stats.get("false_positives") or 0)
            output.append({
                "rule_id":rid,"name":rule.get("name"),"category":rule.get("category"),
                "severity":rule.get("severity"),"event_id":rule.get("event_id"),
                "configured":True,"alert_count":count,"false_positives":fp,
                "open_alerts":int(stats.get("open_alerts") or 0),
                "false_positive_rate_pct":round(fp/count*100,2) if count else None,
                "last_alert_at":stats.get("last_alert_at"),
                "operational_state":"FIRED" if count else "NOT_OBSERVED",
            })
        return output
    finally: conn.close()

def get_detection_quality_summary():
    rows=get_detection_quality()
    fired=[r for r in rows if r["alert_count"]]
    total_alerts=sum(r["alert_count"] for r in rows)
    total_fp=sum(r["false_positives"] for r in rows)
    return {
        "configured_rules":len(rows),"rules_observed":len(fired),
        "rules_not_observed":len(rows)-len(fired),"total_alerts":total_alerts,
        "false_positives":total_fp,
        "false_positive_rate_pct":round(total_fp/total_alerts*100,2) if total_alerts else 0.0,
        "rules":rows,
    }
