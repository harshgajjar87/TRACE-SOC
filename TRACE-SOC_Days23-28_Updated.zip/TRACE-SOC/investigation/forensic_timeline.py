"""Day 24: forensic timeline analysis and event-gap annotation."""
from datetime import datetime, timezone
from investigation.timeline import get_story_timeline

def _parse(value):
    if not value: return None
    try:
        dt=datetime.fromisoformat(str(value).replace("Z","+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except (ValueError,TypeError): return None

def analyze_forensic_timeline(story_id, gap_threshold_minutes=15):
    """Return ordered timeline rows annotated with elapsed time and notable gaps."""
    threshold=max(1,min(int(gap_threshold_minutes),1440))
    result=get_story_timeline(int(story_id))
    events=result["timeline"]
    previous=None
    annotated=[]
    for event in events:
        item=dict(event)
        current=_parse(item.get("timestamp_utc") or item.get("observed_at_utc"))
        gap=None
        if current and previous:
            gap=(current-previous).total_seconds()/60
        item["gap_from_previous_minutes"]=round(gap,2) if gap is not None else None
        item["timeline_marker"]="LARGE_GAP" if gap is not None and gap>=threshold else "EVENT"
        if current: previous=current
        annotated.append(item)
    gaps=[e for e in annotated if e["timeline_marker"]=="LARGE_GAP"]
    return {
        "story":result["story"],
        "events":annotated,
        "relationships":result["relationships"],
        "statistics":{
            "event_count":len(annotated),
            "large_gap_count":len(gaps),
            "first_event":annotated[0].get("timestamp_utc") if annotated else None,
            "last_event":annotated[-1].get("timestamp_utc") if annotated else None,
            "threshold_minutes":threshold,
        },
    }
