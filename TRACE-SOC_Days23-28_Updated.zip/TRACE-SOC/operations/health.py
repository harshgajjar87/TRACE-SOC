"""Day 28: local database, schema and SOC pipeline health checks."""
import os
from database import db

EXPECTED_TABLES={
    "raw_events","normalized_events","alerts","attack_stories","story_events",
    "ioc_indicators","incident_cases","monitoring_runs","monitoring_status",
    "monitoring_analysis_runs","evidence_custody",
}

def create_performance_indexes():
    """Add safe, non-destructive indexes for common hunt and triage filters."""
    conn=db.get_connection()
    statements=[
        "CREATE INDEX IF NOT EXISTS idx_ne_source_ip ON normalized_events(source_ip)",
        "CREATE INDEX IF NOT EXISTS idx_ne_destination_ip ON normalized_events(destination_ip)",
        "CREATE INDEX IF NOT EXISTS idx_ne_process_guid ON normalized_events(process_guid)",
        "CREATE INDEX IF NOT EXISTS idx_ne_parent_process_guid ON normalized_events(parent_process_guid)",
        "CREATE INDEX IF NOT EXISTS idx_ne_host_time ON normalized_events(hostname,timestamp_utc)",
        "CREATE INDEX IF NOT EXISTS idx_ne_user_time ON normalized_events(username,timestamp_utc)",
        "CREATE INDEX IF NOT EXISTS idx_alert_rule_status ON alerts(rule_id,status)",
        "CREATE INDEX IF NOT EXISTS idx_alert_created ON alerts(created_at_utc)",
        "CREATE INDEX IF NOT EXISTS idx_raw_timestamp ON raw_events(timestamp_utc)",
    ]
    try:
        with conn:
            for sql in statements: conn.execute(sql)
        return len(statements)
    finally: conn.close()

def get_system_health():
    """Run lightweight SQLite checks and report component table availability."""
    conn=db.get_connection()
    try:
        quick=conn.execute("PRAGMA quick_check").fetchone()[0]
        fk_issues=[dict(r) for r in conn.execute("PRAGMA foreign_key_check").fetchall()]
        tables={r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        counts={}
        for table in ("raw_events","normalized_events","alerts","attack_stories",
                      "ioc_indicators","incident_cases","evidence_custody","ioc_sightings"):
            if table in tables:
                counts[table]=int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
        indexes=[r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='index'")]
        missing=sorted(EXPECTED_TABLES-tables)
        return {
            "database_path":str(db.DATABASE_PATH),
            "database_exists":db.DATABASE_PATH.exists(),
            "database_size_bytes":db.DATABASE_PATH.stat().st_size if db.DATABASE_PATH.exists() else 0,
            "sqlite_quick_check":quick,
            "foreign_key_issues":fk_issues,
            "missing_expected_tables":missing,
            "table_counts":counts,
            "performance_indexes_present":sum(1 for name in indexes if name.startswith(("idx_ne_","idx_alert_","idx_raw_"))),
            "sqlite_version":conn.execute("SELECT sqlite_version()").fetchone()[0],
        }
    finally: conn.close()
