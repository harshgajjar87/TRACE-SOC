"""TRACE-SOC operational readiness modules."""
