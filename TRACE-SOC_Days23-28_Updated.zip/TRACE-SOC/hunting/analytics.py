"""Day 23: pivot-based threat hunting analytics."""
from datetime import datetime, timezone, timedelta
from database.db import get_connection

def get_related_events(normalized_event_id, window_minutes=15, limit=200):
    """Pivot from one event to same-host/user/IP/process events in a bounded window."""
    window_minutes=max(1,min(int(window_minutes),1440))
    limit=max(1,min(int(limit),1000))
    conn=get_connection()
    try:
        anchor=conn.execute("""SELECT id,timestamp_utc,hostname,username,source_ip,
            destination_ip,process_guid,parent_process_guid FROM normalized_events WHERE id=?""",
            (int(normalized_event_id),)).fetchone()
        if not anchor: raise ValueError(f"Normalized event {normalized_event_id} was not found.")
        if not anchor["timestamp_utc"]: return []
        try:
            dt=datetime.fromisoformat(anchor["timestamp_utc"].replace("Z","+00:00"))
            if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
            start=(dt-timedelta(minutes=window_minutes)).astimezone(timezone.utc).isoformat()
            end=(dt+timedelta(minutes=window_minutes)).astimezone(timezone.utc).isoformat()
        except ValueError: return []
        clauses=["timestamp_utc BETWEEN ? AND ?"]
        params=[start,end]
        pivots=[]
        for field in ("hostname","username","source_ip","destination_ip","process_guid","parent_process_guid"):
            value=anchor[field]
            if value not in (None,""):
                pivots.append(field)
                clauses.append(f"{field} = ?")
                params.append(value)
        if not pivots: return []
        sql="""SELECT id AS normalized_event_id,raw_event_id,event_id,timestamp_utc,
            hostname,username,source_ip,destination_ip,image,command_line,process_guid,
            parent_process_guid,event_type FROM normalized_events WHERE """ + " OR ".join(clauses)
        # Time bound applies to every pivot clause.
        sql="""SELECT id AS normalized_event_id,raw_event_id,event_id,timestamp_utc,
            hostname,username,source_ip,destination_ip,image,command_line,process_guid,
            parent_process_guid,event_type FROM normalized_events
            WHERE timestamp_utc BETWEEN ? AND ? AND (""" + " OR ".join(f"{f}=?" for f in pivots) + ") ORDER BY timestamp_utc ASC,id ASC LIMIT ?"
        values=[start,end]+[anchor[f] for f in pivots]+[limit]
        return [dict(r) for r in conn.execute(sql,values).fetchall()]
    finally: conn.close()

def get_process_lineage(normalized_event_id, limit=500):
    """Return events sharing a process GUID or parent-process GUID with the selected event."""
    limit=max(1,min(int(limit),2000))
    conn=get_connection()
    try:
        row=conn.execute("SELECT process_guid,parent_process_guid,hostname FROM normalized_events WHERE id=?",
                         (int(normalized_event_id),)).fetchone()
        if not row: raise ValueError(f"Normalized event {normalized_event_id} was not found.")
        guids=[g for g in (row["process_guid"],row["parent_process_guid"]) if g]
        if not guids: return []
        marks=",".join("?" for _ in guids)
        sql=f"""SELECT id AS normalized_event_id,timestamp_utc,event_id,hostname,username,
            process_id,parent_process_id,process_guid,parent_process_guid,image,command_line
            FROM normalized_events WHERE hostname IS ? AND
            (process_guid IN ({marks}) OR parent_process_guid IN ({marks}))
            ORDER BY timestamp_utc ASC,id ASC LIMIT ?"""
        return [dict(r) for r in conn.execute(sql,[row["hostname"],*guids,*guids,limit]).fetchall()]
    finally: conn.close()

def get_hunt_activity_summary(limit=5000):
    """Summarize stored telemetry by host, account, event ID and process image."""
    limit=max(1,min(int(limit),20000))
    conn=get_connection()
    try:
        total=conn.execute("SELECT COUNT(*) FROM normalized_events").fetchone()[0]
        def grouped(sql):
            return [dict(r) for r in conn.execute(sql,(limit,)).fetchall()]
        return {
            "total_events":total,
            "hosts":grouped("""SELECT COALESCE(hostname,'Unknown') AS label,COUNT(*) AS count FROM normalized_events GROUP BY hostname ORDER BY count DESC LIMIT ?"""),
            "users":grouped("""SELECT COALESCE(username,'Unknown') AS label,COUNT(*) AS count FROM normalized_events GROUP BY username ORDER BY count DESC LIMIT ?"""),
            "event_ids":grouped("""SELECT COALESCE(event_id,'Unknown') AS label,COUNT(*) AS count FROM normalized_events GROUP BY event_id ORDER BY count DESC LIMIT ?"""),
            "processes":grouped("""SELECT COALESCE(image,'Unknown') AS label,COUNT(*) AS count FROM normalized_events WHERE image IS NOT NULL AND image<>'' GROUP BY image ORDER BY count DESC LIMIT ?"""),
        }
    finally: conn.close()
