import hashlib
import json
import pytest

import database.db as db
from database.db import create_tables, get_connection
from investigation.story_schema import create_story_tables
from hunting.analytics import get_related_events, get_process_lineage, get_hunt_activity_summary
from investigation.forensic_timeline import analyze_forensic_timeline
from detection.quality import get_detection_quality_summary
from threat_intel.engine import create_threat_intel_schema, add_indicator
from threat_intel.correlation import create_ioc_sighting_schema, run_ioc_correlation, get_ioc_sightings
from reports.analyst_exports import build_investigation_package, investigation_timeline_csv
from operations.health import create_performance_indexes, get_system_health


@pytest.fixture
def project_db(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "trace_test.db")
    create_tables()
    create_story_tables()
    create_threat_intel_schema()
    create_ioc_sighting_schema()
    conn=get_connection()
    xml=b"<Event><System><EventID>1</EventID></System></Event>"
    digest=hashlib.sha256(xml).hexdigest()
    with conn:
        raw=conn.execute("""INSERT INTO raw_events(event_fingerprint,source_file,source_file_sha256,
            raw_xml,event_id,provider,channel,record_id,timestamp_utc,hostname,collected_at_utc)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)""",("fp1","test.xml",digest,xml,"1","Sysmon","Sysmon","1",
            "2026-11-11T10:00:00+00:00","TEST-PC","2026-11-11T10:00:01+00:00")).lastrowid
        norm=conn.execute("""INSERT INTO normalized_events(raw_event_id,event_id,provider,channel,
            timestamp_utc,hostname,username,process_id,parent_process_id,process_guid,
            parent_process_guid,image,command_line,source_ip,destination_ip,event_type,extra_data_json)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(raw,"1","Sysmon","Sysmon",
            "2026-11-11T10:00:00+00:00","TEST-PC","alice",100,50,"{PROC-1}","{PARENT-1}",
            "C:\\Windows\\System32\\cmd.exe","cmd.exe /c whoami","198.51.100.25","203.0.113.10",
            "Process Create","{}")).lastrowid
        story=conn.execute("""INSERT INTO attack_stories(story_fingerprint,title,description,severity,status,
            hostname,username,source_ip,first_seen,last_seen,event_count,alert_count,confidence_score,
            confidence_level,created_at_utc) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            ("storyfp","Test story","Test description","MEDIUM","NEW","TEST-PC","alice",
             "198.51.100.25","2026-11-11T10:00:00+00:00","2026-11-11T10:00:00+00:00",
             1,0,70,"MEDIUM","2026-11-11T10:00:02+00:00")).lastrowid
        conn.execute("""INSERT INTO story_events(story_id,normalized_event_id,relationship,evidence_role,observed_at_utc)
            VALUES(?,?,?,?,?)""",(story,norm,"SAME_HOST_USER","PRIMARY","2026-11-11T10:00:00+00:00"))
    conn.close()
    return {"raw":raw,"normalized":norm,"story":story}


def test_day23_hunt_pivot_and_summary(project_db):
    event_id=project_db["normalized"]
    related=get_related_events(event_id)
    lineage=get_process_lineage(event_id)
    summary=get_hunt_activity_summary()
    assert any(row["normalized_event_id"]==event_id for row in related)
    assert any(row["normalized_event_id"]==event_id for row in lineage)
    assert summary["total_events"]==1


def test_day24_timeline_annotations(project_db):
    result=analyze_forensic_timeline(project_db["story"],10)
    assert result["statistics"]["event_count"]==1
    assert result["events"][0]["timeline_marker"]=="EVENT"


def test_day25_detection_quality_includes_configured_rules(project_db):
    result=get_detection_quality_summary()
    assert result["configured_rules"]>0
    assert result["rules_not_observed"]>=0


def test_day26_ioc_correlation_persists_sighting(project_db):
    add_indicator("198.51.100.25","IP","Unit Test Feed",confidence=90,severity="HIGH")
    result=run_ioc_correlation()
    rows=get_ioc_sightings()
    assert result["events_scanned"]>=1
    assert any(row["indicator"]=="198.51.100.25" for row in rows)


def test_day27_report_package_and_csv(project_db):
    package=build_investigation_package(project_db["story"])
    csv_text=investigation_timeline_csv(project_db["story"])
    assert package["story"]["id"]==project_db["story"]
    assert "timestamp_utc" in csv_text


def test_day28_health_and_indexes(project_db):
    created=create_performance_indexes()
    health=get_system_health()
    assert created>=1
    assert health["sqlite_quick_check"]=="ok"
    assert health["table_counts"]["normalized_events"]==1
